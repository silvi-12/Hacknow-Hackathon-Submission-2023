import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // urscheduleDhb (1:3)
        padding: EdgeInsets.fromLTRB(12*fem, 10*fem, 13*fem, 11*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
          borderRadius: BorderRadius.circular(15*fem),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogrouphb8si8Z (UpWcgjE5GHgm93fte4HB8s)
              width: double.infinity,
              height: 557*fem,
              child: Stack(
                children: [
                  Positioned(
                    // rectangle4CpR (3:13)
                    left: 1*fem,
                    top: 2*fem,
                    child: Align(
                      child: SizedBox(
                        width: 334*fem,
                        height: 555*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xfffffaef),
                            borderRadius: BorderRadius.only (
                              topLeft: Radius.circular(15*fem),
                              topRight: Radius.circular(15*fem),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle1hFP (3:7)
                    left: 0*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 335*fem,
                        height: 140*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            gradient: LinearGradient (
                              begin: Alignment(1, -0.8),
                              end: Alignment(-1, 1),
                              colors: <Color>[Color(0xff8be3c3), Color(0x6be4aaf8), Color(0x00d9d9d9)],
                              stops: <double>[0.346, 0.751, 1],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // vectorM53 (5:148)
                    left: 272*fem,
                    top: 23*fem,
                    child: Align(
                      child: SizedBox(
                        width: 7.41*fem,
                        height: 12*fem,
                        child: Image.asset(
                          'assets/page-1/images/vector-cPT.png',
                          width: 7.41*fem,
                          height: 12*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // vectorTtm (5:149)
                    left: 296.9842529297*fem,
                    top: 22.9902648926*fem,
                    child: Align(
                      child: SizedBox(
                        width: 7.44*fem,
                        height: 12.02*fem,
                        child: Image.asset(
                          'assets/page-1/images/vector.png',
                          width: 7.44*fem,
                          height: 12.02*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // doubleleftC5f (5:147)
                    left: 162*fem,
                    top: 123*fem,
                    child: Align(
                      child: SizedBox(
                        width: 12.01*fem,
                        height: 12.01*fem,
                        child: Image.asset(
                          'assets/page-1/images/double-left.png',
                          fit: BoxFit.contain,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // today7TX (3:10)
                    left: 17*fem,
                    top: 165*fem,
                    child: Align(
                      child: SizedBox(
                        width: 35*fem,
                        height: 15*fem,
                        child: Text(
                          'Today',
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.2125*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle2CE5 (3:11)
                    left: 19*fem,
                    top: 191*fem,
                    child: Align(
                      child: SizedBox(
                        width: 285*fem,
                        height: 63*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle12iTK (4:80)
                    left: 19*fem,
                    top: 270*fem,
                    child: Align(
                      child: SizedBox(
                        width: 285*fem,
                        height: 63*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle14pmF (4:90)
                    left: 19*fem,
                    top: 349*fem,
                    child: Align(
                      child: SizedBox(
                        width: 285*fem,
                        height: 63*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // jan230800090092q (4:76)
                    left: 96*fem,
                    top: 226*fem,
                    child: Align(
                      child: SizedBox(
                        width: 79*fem,
                        height: 10*fem,
                        child: Text(
                          'Jan 23, 08:00-09:00',
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 8*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2125*ffem/fem,
                            color: Color(0xffb8b8b8),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // jan2301000120038D (4:81)
                    left: 96*fem,
                    top: 305*fem,
                    child: Align(
                      child: SizedBox(
                        width: 81*fem,
                        height: 10*fem,
                        child: Text(
                          'Jan 23, 010:00-12:00',
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 8*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2125*ffem/fem,
                            color: Color(0xffb8b8b8),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // jan2320002100KbX (4:91)
                    left: 96*fem,
                    top: 384*fem,
                    child: Align(
                      child: SizedBox(
                        width: 77*fem,
                        height: 10*fem,
                        child: Text(
                          'Jan 23, 20:00-21:00',
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 8*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2125*ffem/fem,
                            color: Color(0xffb8b8b8),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // restaurantdMK (4:70)
                    left: 43*fem,
                    top: 209*fem,
                    child: Align(
                      child: SizedBox(
                        width: 24*fem,
                        height: 24*fem,
                        child: Image.asset(
                          'assets/page-1/images/restaurant.png',
                          width: 24*fem,
                          height: 24*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle11YDP (4:69)
                    left: 31*fem,
                    top: 200*fem,
                    child: Align(
                      child: SizedBox(
                        width: 47*fem,
                        height: 43*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(12*fem),
                            color: Color(0x6be4aaf8),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle13eGR (4:85)
                    left: 31*fem,
                    top: 279*fem,
                    child: Align(
                      child: SizedBox(
                        width: 47*fem,
                        height: 43*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(12*fem),
                            color: Color(0xa3ffc8cc),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // electriccarxnu (4:103)
                    left: 43*fem,
                    top: 289*fem,
                    child: Align(
                      child: SizedBox(
                        width: 24*fem,
                        height: 24*fem,
                        child: Image.asset(
                          'assets/page-1/images/electric-car.png',
                          width: 24*fem,
                          height: 24*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle15H4V (4:95)
                    left: 31*fem,
                    top: 358*fem,
                    child: Align(
                      child: SizedBox(
                        width: 47*fem,
                        height: 43*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(12*fem),
                            color: Color(0x518be3c3),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // eatbreakfastCSM (4:73)
                    left: 96*fem,
                    top: 210*fem,
                    child: Align(
                      child: SizedBox(
                        width: 80*fem,
                        height: 15*fem,
                        child: Text(
                          'Eat Breakfast ',
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.2125*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // drivingtestubf (4:86)
                    left: 96*fem,
                    top: 289*fem,
                    child: Align(
                      child: SizedBox(
                        width: 67*fem,
                        height: 15*fem,
                        child: Text(
                          'Driving test',
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.2125*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // readbook1ub (4:96)
                    left: 96*fem,
                    top: 368*fem,
                    child: Align(
                      child: SizedBox(
                        width: 65*fem,
                        height: 15*fem,
                        child: Text(
                          'Read book ',
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.2125*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse4KfP (4:77)
                    left: 262*fem,
                    top: 220*fem,
                    child: Align(
                      child: SizedBox(
                        width: 5*fem,
                        height: 5*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(2.5*fem),
                            color: Color(0xff436e87),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse73rH (4:87)
                    left: 262*fem,
                    top: 299*fem,
                    child: Align(
                      child: SizedBox(
                        width: 5*fem,
                        height: 5*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(2.5*fem),
                            color: Color(0xff436e87),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse10NNm (4:97)
                    left: 262*fem,
                    top: 378*fem,
                    child: Align(
                      child: SizedBox(
                        width: 5*fem,
                        height: 5*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(2.5*fem),
                            color: Color(0xff436e87),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse5tM7 (4:78)
                    left: 274*fem,
                    top: 220*fem,
                    child: Align(
                      child: SizedBox(
                        width: 5*fem,
                        height: 5*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(2.5*fem),
                            color: Color(0xff436e87),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse8oDB (4:88)
                    left: 274*fem,
                    top: 299*fem,
                    child: Align(
                      child: SizedBox(
                        width: 5*fem,
                        height: 5*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(2.5*fem),
                            color: Color(0xff436e87),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse11X9B (4:98)
                    left: 274*fem,
                    top: 378*fem,
                    child: Align(
                      child: SizedBox(
                        width: 5*fem,
                        height: 5*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(2.5*fem),
                            color: Color(0xff436e87),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse6qvZ (4:79)
                    left: 268*fem,
                    top: 220*fem,
                    child: Align(
                      child: SizedBox(
                        width: 5*fem,
                        height: 5*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(2.5*fem),
                            color: Color(0xff436e87),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse9Nfb (4:89)
                    left: 268*fem,
                    top: 299*fem,
                    child: Align(
                      child: SizedBox(
                        width: 5*fem,
                        height: 5*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(2.5*fem),
                            color: Color(0xff436e87),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // ellipse12aWm (4:99)
                    left: 268*fem,
                    top: 378*fem,
                    child: Align(
                      child: SizedBox(
                        width: 5*fem,
                        height: 5*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(2.5*fem),
                            color: Color(0xff436e87),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // bookmarksVtd (4:100)
                    left: 43*fem,
                    top: 367*fem,
                    child: Align(
                      child: SizedBox(
                        width: 24*fem,
                        height: 24*fem,
                        child: Image.asset(
                          'assets/page-1/images/bookmarks.png',
                          width: 24*fem,
                          height: 24*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // tomorrowouK (4:109)
                    left: 25*fem,
                    top: 434*fem,
                    child: Align(
                      child: SizedBox(
                        width: 58*fem,
                        height: 15*fem,
                        child: Text(
                          'Tomorrow',
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.2125*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle217v1 (5:127)
                    left: 34*fem,
                    top: 78*fem,
                    child: Align(
                      child: SizedBox(
                        width: 21*fem,
                        height: 31*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                            color: Color(0xadffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle2232y (5:132)
                    left: 76*fem,
                    top: 78*fem,
                    child: Align(
                      child: SizedBox(
                        width: 21*fem,
                        height: 31*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                            color: Color(0xadffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle23xQq (5:133)
                    left: 118*fem,
                    top: 78*fem,
                    child: Align(
                      child: SizedBox(
                        width: 21*fem,
                        height: 31*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                            color: Color(0xadffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle24g5w (5:134)
                    left: 160*fem,
                    top: 78*fem,
                    child: Align(
                      child: SizedBox(
                        width: 21*fem,
                        height: 31*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                            color: Color(0xadffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle25bih (5:135)
                    left: 202*fem,
                    top: 78*fem,
                    child: Align(
                      child: SizedBox(
                        width: 21*fem,
                        height: 31*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                            color: Color(0xadffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle26Keh (5:136)
                    left: 244*fem,
                    top: 78*fem,
                    child: Align(
                      child: SizedBox(
                        width: 21*fem,
                        height: 31*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                            color: Color(0xadffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle27Rxd (5:137)
                    left: 286*fem,
                    top: 78*fem,
                    child: Align(
                      child: SizedBox(
                        width: 21*fem,
                        height: 31*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(8*fem),
                            color: Color(0xadffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // fjyK (5:145)
                    left: 251*fem,
                    top: 62*fem,
                    child: Align(
                      child: SizedBox(
                        width: 8*fem,
                        height: 15*fem,
                        child: Text(
                          'F',
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.2125*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // sT8d (5:146)
                    left: 293*fem,
                    top: 62*fem,
                    child: Align(
                      child: SizedBox(
                        width: 8*fem,
                        height: 15*fem,
                        child: Text(
                          'S',
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.2125*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // tAYq (5:144)
                    left: 209*fem,
                    top: 62*fem,
                    child: Align(
                      child: SizedBox(
                        width: 8*fem,
                        height: 15*fem,
                        child: Text(
                          'T',
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.2125*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // sgn5 (5:140)
                    left: 41*fem,
                    top: 62*fem,
                    child: Align(
                      child: SizedBox(
                        width: 8*fem,
                        height: 15*fem,
                        child: Text(
                          'S',
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.2125*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // w13f (5:143)
                    left: 165*fem,
                    top: 62*fem,
                    child: Align(
                      child: SizedBox(
                        width: 12*fem,
                        height: 15*fem,
                        child: Text(
                          'W',
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.2125*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // tuPw (5:142)
                    left: 125*fem,
                    top: 62*fem,
                    child: Align(
                      child: SizedBox(
                        width: 8*fem,
                        height: 15*fem,
                        child: Text(
                          'T',
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.2125*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // m2Df (5:141)
                    left: 82*fem,
                    top: 62*fem,
                    child: Align(
                      child: SizedBox(
                        width: 11*fem,
                        height: 15*fem,
                        child: Text(
                          'M',
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.2125*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // saturday22janw5j (5:150)
                    left: 19*fem,
                    top: 20*fem,
                    child: Align(
                      child: SizedBox(
                        width: 97*fem,
                        height: 15*fem,
                        child: Text(
                          'Saturday, 22 Jan',
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 12*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.2125*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupjrawqgu (UpWdaY55miMNBqdprVjRaw)
              margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
              padding: EdgeInsets.fromLTRB(27*fem, 13*fem, 18*fem, 13*fem),
              height: 62*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                borderRadius: BorderRadius.only (
                  bottomRight: Radius.circular(15*fem),
                  bottomLeft: Radius.circular(15*fem),
                ),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // group3iVo (5:126)
                    margin: EdgeInsets.fromLTRB(0*fem, 11*fem, 35*fem, 10*fem),
                    width: 15*fem,
                    height: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // autogroupvsswqqK (UpWdq2ew9ZQ9Rg7bVAvsSw)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 3*fem),
                          width: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // rectangle19zrd (5:124)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                width: 6*fem,
                                height: 6*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xffd9d9d9),
                                ),
                              ),
                              Container(
                                // rectangle18hW9 (5:123)
                                width: 6*fem,
                                height: 6*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xffd9d9d9),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroupgqxfeRP (UpWdvMqPJvmqQ6cUZzgQxf)
                          width: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // rectangle17Q9f (5:122)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
                                width: 6*fem,
                                height: 6*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xffd9d9d9),
                                ),
                              ),
                              Container(
                                // rectangle20LJD (5:125)
                                width: 6*fem,
                                height: 6*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xffd9d9d9),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // alarmclockHjF (5:121)
                    margin: EdgeInsets.fromLTRB(0*fem, 4*fem, 48*fem, 0*fem),
                    width: 24*fem,
                    height: 24*fem,
                    child: Image.asset(
                      'assets/page-1/images/alarm-clock.png',
                      fit: BoxFit.contain,
                    ),
                  ),
                  Container(
                    // group21fF (4:112)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 48*fem, 0*fem),
                    width: 36*fem,
                    height: 36*fem,
                    child: Image.asset(
                      'assets/page-1/images/group-2.png',
                      width: 36*fem,
                      height: 36*fem,
                    ),
                  ),
                  Container(
                    // groupwJ1 (5:117)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 47*fem, 0*fem),
                    width: 20*fem,
                    height: 20*fem,
                    child: Image.asset(
                      'assets/page-1/images/group.png',
                      width: 20*fem,
                      height: 20*fem,
                    ),
                  ),
                  Container(
                    // vectorTXF (5:116)
                    width: 16*fem,
                    height: 16*fem,
                    child: Image.asset(
                      'assets/page-1/images/vector-VTw.png',
                      width: 16*fem,
                      height: 16*fem,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}