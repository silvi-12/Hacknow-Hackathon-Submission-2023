import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 360;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // createtaskpageUXs (3:14)
        width: double.infinity,
        height: 640*fem,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
          borderRadius: BorderRadius.circular(15*fem),
        ),
        child: Stack(
          children: [
            Positioned(
              // rectangle1v2V (3:16)
              left: 10*fem,
              top: 8*fem,
              child: Align(
                child: SizedBox(
                  width: 342*fem,
                  height: 154*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(15*fem),
                      color: Color(0xfffffaef),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // tasknameoMB (3:25)
              left: 36*fem,
              top: 120*fem,
              child: Align(
                child: SizedBox(
                  width: 67*fem,
                  height: 18*fem,
                  child: Text(
                    'Task Name',
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.5*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // nameFys (3:22)
              left: 36*fem,
              top: 99*fem,
              child: Align(
                child: SizedBox(
                  width: 25*fem,
                  height: 12*fem,
                  child: Text(
                    'Name',
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 8*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.5*ffem/fem,
                      color: Color(0xffb8b6b6),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle48nm (3:15)
              left: 10*fem,
              top: 147*fem,
              child: Align(
                child: SizedBox(
                  width: 342*fem,
                  height: 476*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(15*fem),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // createnewtaskSoT (3:21)
              left: 36*fem,
              top: 49*fem,
              child: Align(
                child: SizedBox(
                  width: 61*fem,
                  height: 36*fem,
                  child: Text(
                    'Create \nNew Task ',
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w600,
                      height: 1.5*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line1XK7 (3:24)
              left: 36*fem,
              top: 138*fem,
              child: Align(
                child: SizedBox(
                  width: 282*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line4qKo (3:34)
              left: 39*fem,
              top: 229*fem,
              child: Align(
                child: SizedBox(
                  width: 282*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffb8b6b6),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line5kBs (3:35)
              left: 39*fem,
              top: 285*fem,
              child: Align(
                child: SizedBox(
                  width: 282*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffb8b6b6),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle54TT (3:26)
              left: 45*fem,
              top: 567*fem,
              child: Align(
                child: SizedBox(
                  width: 271*fem,
                  height: 46*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(15*fem),
                      color: Color(0xff034063),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse3aRo (4:60)
              left: 260*fem,
              top: 504*fem,
              child: Align(
                child: SizedBox(
                  width: 19*fem,
                  height: 18*fem,
                  child: Image.asset(
                    'assets/page-1/images/ellipse-3.png',
                    width: 19*fem,
                    height: 18*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // line6thP (4:61)
              left: 269*fem,
              top: 508*fem,
              child: Align(
                child: SizedBox(
                  width: 1*fem,
                  height: 9*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group1oZT (4:111)
              left: 131*fem,
              top: 581*fem,
              child: Align(
                child: SizedBox(
                  width: 19*fem,
                  height: 18*fem,
                  child: Image.asset(
                    'assets/page-1/images/group-1.png',
                    width: 19*fem,
                    height: 18*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // line7v8H (4:62)
              left: 265.0066070557*fem,
              top: 511.8933105469*fem,
              child: Align(
                child: SizedBox(
                  width: 8.99*fem,
                  height: 0.23*fem,
                  child: Image.asset(
                    'assets/page-1/images/line-7.png',
                    width: 8.99*fem,
                    height: 0.23*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // createtask1fX (3:31)
              left: 157*fem,
              top: 583*fem,
              child: Align(
                child: SizedBox(
                  width: 81*fem,
                  height: 15*fem,
                  child: Text(
                    'CREATE TASK',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.2125*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // dateWsB (3:32)
              left: 39*fem,
              top: 192*fem,
              child: Align(
                child: SizedBox(
                  width: 27*fem,
                  height: 15*fem,
                  child: Text(
                    'Date',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.2125*ffem/fem,
                      color: Color(0xffb8b6b6),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // startingtimedB7 (3:33)
              left: 39*fem,
              top: 242*fem,
              child: Align(
                child: SizedBox(
                  width: 78*fem,
                  height: 15*fem,
                  child: Text(
                    'Starting Time',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.2125*ffem/fem,
                      color: Color(0xffb8b6b6),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle6wBo (3:36)
              left: 39*fem,
              top: 324*fem,
              child: Align(
                child: SizedBox(
                  width: 45*fem,
                  height: 39*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(15*fem),
                      color: Color(0xffebebeb),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // circlenotificationsTA9 (3:37)
              left: 50*fem,
              top: 331*fem,
              child: Align(
                child: SizedBox(
                  width: 24*fem,
                  height: 24*fem,
                  child: Image.asset(
                    'assets/page-1/images/circle-notifications.png',
                    width: 24*fem,
                    height: 24*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // remindmexch (3:41)
              left: 102*fem,
              top: 334*fem,
              child: Align(
                child: SizedBox(
                  width: 64*fem,
                  height: 15*fem,
                  child: Text(
                    'Remind Me',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // scheduleekR (4:47)
              left: 302*fem,
              top: 263*fem,
              child: Align(
                child: SizedBox(
                  width: 17*fem,
                  height: 17*fem,
                  child: Image.asset(
                    'assets/page-1/images/schedule.png',
                    width: 17*fem,
                    height: 17*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // categorymKF (4:50)
              left: 45*fem,
              top: 407*fem,
              child: Align(
                child: SizedBox(
                  width: 57*fem,
                  height: 15*fem,
                  child: Text(
                    'Category ',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.2125*ffem/fem,
                      color: Color(0xffb8b6b6),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle7Ths (4:51)
              left: 46*fem,
              top: 434*fem,
              child: Align(
                child: SizedBox(
                  width: 77*fem,
                  height: 35*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(12*fem),
                      color: Color(0xa3ffc8f6),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // studyygD (4:55)
              left: 68*fem,
              top: 444*fem,
              child: Align(
                child: SizedBox(
                  width: 34*fem,
                  height: 15*fem,
                  child: Text(
                    'Study',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.2125*ffem/fem,
                      color: Color(0xffd518b7),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle8Uss (4:53)
              left: 136*fem,
              top: 434*fem,
              child: Align(
                child: SizedBox(
                  width: 101*fem,
                  height: 35*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(12*fem),
                      color: Color(0xa3ffc8cc),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle9bBo (4:54)
              left: 250*fem,
              top: 434*fem,
              child: Align(
                child: SizedBox(
                  width: 77*fem,
                  height: 35*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(12*fem),
                      color: Color(0xa3d3c8ff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle10uyB (4:58)
              left: 250*fem,
              top: 495*fem,
              child: Align(
                child: SizedBox(
                  width: 83*fem,
                  height: 35*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(15*fem),
                      color: Color(0xa3ffdaaf),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // addtagEEm (4:63)
              left: 281*fem,
              top: 507*fem,
              child: Align(
                child: SizedBox(
                  width: 40*fem,
                  height: 13*fem,
                  child: Text(
                    'Add Tag',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 10*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.2125*ffem/fem,
                      color: Color(0xffffb55f),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // productivejhK (4:56)
              left: 156*fem,
              top: 445*fem,
              child: Align(
                child: SizedBox(
                  width: 62*fem,
                  height: 15*fem,
                  child: Text(
                    'Productive',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.2125*ffem/fem,
                      color: Color(0xffb80e0e),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // lifeSbj (4:57)
              left: 279*fem,
              top: 444*fem,
              child: Align(
                child: SizedBox(
                  width: 21*fem,
                  height: 15*fem,
                  child: Text(
                    'Life',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff75009e),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}